#pragma once
#include <stdint.h>

void kprint(const char* s);
void kprint_hex(uint64_t v);